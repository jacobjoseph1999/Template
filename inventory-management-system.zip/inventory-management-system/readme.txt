T�l�charger gratuitement le code source � Advance Inventory Management System �

PREMIER t�l�chargement

1.XAMPP

2."TEXT EDITOR � NOTEPAD++ OU SUBLIME TEXTE 3 / ETC.

3"inventaire-gestion-syst�me �

4. T�l�charger le fichier zip / t�l�charger winrar

5. Extraire le fichier et copier le dossier � syst�me de gestion des stocks �

6.Paste � l�int�rieur du r�pertoire de racine/ o� vous installez xammp disque local C : lecteur D : lecteur E : coller : (pour xampp/htdocs,

7. Ouvrez PHPMyAdmin (http://localhost/phpmyadmin)

8. Cr�er une base de donn�es avec le nom shop_inventory

6. Importer un fichier shop_inventory.sql (donn� � l�int�rieur du paquet zip dans le dossier de fichier SQL)

7.Ex�cuter le script http://localhost/inventory-management-system

**D�TAILS DE CONNEXION**

nom d�utilisateur: admin
mot de passe: admin


ABONNEZ VOUS A MA CHAINE startedproject https://www.youtube.com/channel/UCSauXgwf81ssx97VHyKKm9A